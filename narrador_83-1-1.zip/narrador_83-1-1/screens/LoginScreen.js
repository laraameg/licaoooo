import React, { Component } from 'react';
import {
  View,
  Text,
  StyleSheet,
  SafeAreaView,
  Platform,
  StatusBar,
  Image,
  ScrollView,
  TextInput,
  KeyboardAvoidingView, 
  TouchableOpacity
} from 'react-native';
import { RFValue } from 'react-native-responsive-fontsize';
import DropDownPicker from 'react-native-dropdown-picker';
import * as Font from 'expo-font';
import * as SplashScreen from 'expo-splash-screen';
import firebase from "firebase"
SplashScreen.preventAutoHideAsync();

let customFonts = {
  'Bubblegum-Sans': require('../assets/fonts/BubblegumSans-Regular.ttf'),
};

export default class LoginScreen extends Component {
  constructor(props) {
    super(props);
    this.state = {
      fontsLoaded: false,
      dropdownHeight: 40,
      email: '',
      password: '',
      userSignedIn: false,
    };
  }

  async _loadFontsAsync() {
    await Font.loadAsync(customFonts);
    this.setState({ fontsLoaded: true });
  }

  componentDidMount() {
    this._loadFontsAsync();
  }
  
    signIn = async (email, password) => {
    firebase
      .auth()
      .signInWithEmailAndPassword(email, password)
      .then(() => {
        this.props.navigation.replace('Dashboard');
      })
      .catch((error) => {
        Alert.alert(error.message);
      });
  }; 

  render() {
     if (this.state.fontsLoaded) {
      SplashScreen.hideAsync();

      return (
        <KeyboardAvoidingView behavior="padding" style={styles.container}>
          <SafeAreaView style={styles.droidSafeArea} />
          <View style={styles.appTitle}>
            <View style={styles.appTitleTextContainer}>
              <Text style={styles.appTitleText}>Tela de Login</Text>
            </View>
          </View>
          <ScrollView>
            <View style={{ height: RFValue(this.state.dropdownHeight) }}>
            </View>
              <TextInput
                style={styles.inputFont1}
                onChangeText={(email) => this.setState({ email })}
                placeholder={'E-mail'}
                placeholderTextColor="white"
              />
              <TextInput
                style={styles.inputFont}
                onChangeText={(password) => this.setState({ password })}
                placeholder={'Senha'}
                placeholderTextColor="white"
              />
              <TouchableOpacity style = {styles.botaoEntrar} onPress = {()=> this.signIn (email,password)}>
              <Text  style = {styles.textEntrar} > Entrar </Text> 
              </TouchableOpacity> 
            </ScrollView>
            <TouchableOpacity style = {styles.botaoEntrar} onPress={()=> this.props.navigation.navigate("RegisterScreen")}>
              <Text  style = {styles.textEntrar} > Criar conta </Text> 
              </TouchableOpacity> 

               
          <View style={{ flex: 0.08 }} />

        </KeyboardAvoidingView>
      );
    } else {
      return <Text>carregando</Text>
    }
  }
}

const styles = StyleSheet.create({
  container: {
    backgroundColor: "#15193c",
    height: "100%"
  },
  droidSafeArea: {
    marginTop: Platform.OS === "android" ? StatusBar.currentHeight : RFValue(35)
  },
  appTitle: {
    height: "15%",
    display: 'flex',
    alignItems: "center",
    justifyContent: "center",
    flexDirection: "row"
  },
  appTitleTextContainer: {
    marginLeft: 20
  },
  appTitleText: {
    color: "white",
    fontSize: RFValue(25),
    fontFamily: "Bubblegum-Sans",
  },

  inputFont1: {
    height: RFValue(40),
    borderColor: 'white',
    borderWidth: RFValue(1),
    borderRadius: RFValue(10),
    paddingLeft: RFValue(10),
    color: 'white',
    marginTop: RFValue(-20),
    fontFamily: 'Bubblegum-Sans',
  },
    inputFont: {
    height: RFValue(40),
    borderColor: 'white',
    borderWidth: RFValue(1),
    borderRadius: RFValue(10),
    paddingLeft: RFValue(10),
    color: 'white',
    marginTop: RFValue(20),
    fontFamily: 'Bubblegum-Sans',
  },
  botaoEntrar: {
    backgroundColor:"lightblue",
    alignSelf: "center",
    marginTop: 50,
    width: 180,
    borderRadius: 5,

  },
  textEntrar: {
    color: "white",
    fontSize: RFValue(18),
    fontFamily: "Bubblegum-Sans",
    textAlign: "center",
  }
});
