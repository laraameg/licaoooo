import React, { Component } from 'react';
import {
  View,
  Text,
  StyleSheet,
  SafeAreaView,
  Platform,
  StatusBar,
  Image,
  ScrollView,
  TextInput,
  KeyboardAvoidingView, 
  TouchableOpacity,
  Alert
} from 'react-native';
import { RFValue } from 'react-native-responsive-fontsize';
import DropDownPicker from 'react-native-dropdown-picker';
import * as Font from 'expo-font';
import * as SplashScreen from 'expo-splash-screen';
import firebase from "firebase"
SplashScreen.preventAutoHideAsync();

let customFonts = {
  'Bubblegum-Sans': require('../assets/fonts/BubblegumSans-Regular.ttf'),
};

export default class RegisterScreen extends Component {
  constructor(props) {
    super(props);
    this.state = {
      fontsLoaded: false,
      dropdownHeight: 40,
      first_name: "",
      last_name: "",
      email: "",
      password: "",
      confirmPassword: "",
    };
  }

  async _loadFontsAsync() {
    await Font.loadAsync(customFonts);
    this.setState({ fontsLoaded: true });
  }

  componentDidMount() {
    this._loadFontsAsync();
  }
 registerUser = (email, password,confirmPassword,first_name,last_name) => {
  if(password==confirmPassword){
    firebase
      .auth()
      .createUserWithEmailAndPassword(email, password)
      .then((userCredential) => {
        Alert.alert("Usuário registrado!");
        console.log(userCredential.user.uid)
        this.props.navigation.replace("Login");
        firebase.database().ref("/users/" + userCredential.user.uid)
                .set({
                  email: userCredential.user.email,
                  first_name: first_name,
                  last_name: last_name,
                })
      })
      .catch(error => {
        Alert.alert(error.message);
      });
    }else{
      Alert.alert("As senhas não são iguais");
    }
  };

  render() {
     if (this.state.fontsLoaded) {
      SplashScreen.hideAsync();

      return (
        <KeyboardAvoidingView behavior="padding" style={styles.container}>
          <SafeAreaView style={styles.droidSafeArea} />
          <View style={styles.appTitle}>
            <View style={styles.appTitleTextContainer}>
              <Text style={styles.appTitleText}>Tela de Registro</Text>
            </View>
          </View>
          <ScrollView>
            <View style={{ height: RFValue(this.state.dropdownHeight) }}>
            </View>
                <TextInput
                style={styles.inputFont}
                onChangeText={(text) => this.setState({ first_name: text })}
                placeholder={'Nome'}
                placeholderTextColor="white"
              />
                 <TextInput
                style={styles.inputFont}
                onChangeText={(text) => this.setState({ last_name: text })}
                placeholder={'Sobrenome'}
                placeholderTextColor="white"
              />
              <TextInput
                style={styles.inputFont}
                onChangeText={(text) => this.setState({ email: text })}
                placeholder={'E-mail'}
                placeholderTextColor="white"
              />
              <TextInput
                style={styles.inputFont}
                onChangeText={(text) => this.setState({ password: text })}
                placeholder={'Senha'}
                placeholderTextColor="white"
              />
              <TextInput
                style={styles.inputFont}
                onChangeText={(text) => this.setState({ confirmPassword: text })}
                placeholder={'Confirmar Senha'}
                placeholderTextColor="white"
              />

              <TouchableOpacity style = {styles.botaoEntrar} onPress = {() => this.registerUser(email, password, confirmPassword,first_name,last_name)}>
              <Text  style = {styles.textEntrar} > Registrar </Text> 
              </TouchableOpacity> 
            </ScrollView>
            <TouchableOpacity style = {styles.botaoEntrar} onPress= {()=> this.props.navigation.navigate("Login")}>
              <Text  style = {styles.textEntrar} > Já tem conta? Log-in. </Text> 
              </TouchableOpacity> 
          <View style={{ flex: 0.08 }} />

        </KeyboardAvoidingView>
      );
    } else {
      return <Text>carregando</Text>
    }
  }
}

const styles = StyleSheet.create({
  container: {
    backgroundColor: "#15193c",
    height: "100%"
  },
  droidSafeArea: {
    marginTop: Platform.OS === "android" ? StatusBar.currentHeight : RFValue(35)
  },
  appTitle: {
    height: "15%",
    display: 'flex',
    alignItems: "center",
    justifyContent: "center",
    flexDirection: "row"
  },
  appTitleTextContainer: {
    marginLeft: 20
  },
  appTitleText: {
    color: "white",
    fontSize: RFValue(25),
    fontFamily: "Bubblegum-Sans",
  },

    inputFont: {
    height: RFValue(40),
    borderColor: 'white',
    borderWidth: RFValue(1),
    borderRadius: RFValue(10),
    paddingLeft: RFValue(10),
    color: 'white',
    marginTop: RFValue(20),
    fontFamily: 'Bubblegum-Sans',
  },
  botaoEntrar: {
    backgroundColor:"lightblue",
    alignSelf: "center",
    marginTop: 50,
    width: 180,
    borderRadius: 5,

  },
  textEntrar: {
    color: "white",
    fontSize: RFValue(18),
    fontFamily: "Bubblegum-Sans",
    textAlign: "center",
  }
});
