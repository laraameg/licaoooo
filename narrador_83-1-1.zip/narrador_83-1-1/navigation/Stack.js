import React from "react";
import { StyleSheet } from "react-native";
import {createStackNavigator} from "@react-navigation/stack";

import LoginScreen from "../screens/LoginScreen"

import RegisterScreen from "../screens/RegisterScreen"

const Stack = createStackNavigator();
const StackNaviagator = () => {
  return (
    <Stack.Navigator>
     <Stack.Screen name = "telaInicial" component = {BottomTabNavigator}/>
     <Stack.Screen name = "telaDeHistorias" component = {StoryScreen}/>
    </Stack.Navigator>
  )
}